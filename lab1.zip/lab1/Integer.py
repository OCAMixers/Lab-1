class Integer:
    def __init__(self, value):
        self.value = value

    def add(self, other):
        if isinstance(other, Integer):
            return Integer(self.value + other.value)
        return "Invalid operation"

    def from_roman(self, roman_str):
        roman = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
        result = 0
        prev_value = 0
        for char in reversed(roman_str):
            current_value = roman[char]
            if current_value < prev_value:
                result -= current_value
            else:
                result += current_value
            prev_value = current_value
        self.value = result
        return self

    def from_string(self, value):
        try:
            self.value = int(value)
        except ValueError:
            return "Invalid string to integer conversion"
        return self


class Float(Integer):
    def __init__(self, value):
        super().__init__(value)

    def from_float(self, value):
        try:
            self.value = float(value)
        except ValueError:
            return "Invalid float conversion"
        return self


# Test code
first_num = Integer(10)
second_num = Integer(0).from_roman("IV")
print(Float(0).from_float("2.6").value)
print(Integer(0).from_string("26").value)
print(first_num.add(second_num).value)
