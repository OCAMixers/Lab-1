class Calculator:
    @staticmethod
    def add(*args):
        return sum(args)

    @staticmethod
    def multiply(*args):
        result = 1
        for num in args:
            result *= num
        return result

    @staticmethod
    def subtract(*args):
        result = args[0]
        for num in args[1:]:
            result -= num
        return result

    @staticmethod
    def divide(*args):
        result = args[0]
        try:
            for num in args[1:]:
                result /= num
        except ZeroDivisionError:
            return "Division by zero is not allowed"
        return result


# Test code
print(Calculator.add(5, 10, 4))  # Kết quả: 19
print(Calculator.multiply(1, 2, 3, 5))  # Kết quả: 30
print(Calculator.divide(100, 2))  # Kết quả: 50.0
print(Calculator.subtract(90, 20, -50, 43, 7))  # Kết quả: 70
